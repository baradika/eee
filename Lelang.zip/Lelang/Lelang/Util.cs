﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lelang
{
    public static class Util
    {
        public static Masyarakat userMasyarakat = new Masyarakat();
        public static Petuga userPetugas = new Petuga();

        public static String toRupiah(int rupiah)
        {
            return $"Rp. {rupiah:N0},00";
        }
        public static String toRupiah(decimal rupiah)
        {
            return $"Rp. {rupiah:N0},00";
        }

        public static String toRupiah(double rupiah)
        {
            return $"Rp. {rupiah:N0},00";
        }

    }
}
