﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common.EntitySql;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lelang
{
    public partial class BarangForm : Form
    {
        LelangEntities db = new LelangEntities();
        Barang barang = null;
        public BarangForm()
        {
            InitializeComponent();
        }

        private void BarangForm_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            db = new LelangEntities();
            dgvBarang.DataSource = db.Barangs.Select(barang => new {
                barang.id_barang,
                barang.nama_barang,
                barang.harga_awal,
                barang.tgl,
                barang.deskripsi_barang
            }).ToList();
        }

        public void ButtonEditAndDelete(Boolean status)
        {
            editBtn.Enabled = status;
            deleteBtn.Enabled = status;
        }

        public void ClearFields()
        {
            saveBtn.Enabled = true;
            barang = null;
            namaBx.Text = "";
            hargaAwalBx.Text = "";
            descBx.Text = "";
            tglDate.Value = DateTime.Now;
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            if(!(int.TryParse(hargaAwalBx.Text, out int hargaAwal)))
            {
                MessageBox.Show("Harga harus berisi digit");
                return;
            }
            var newBarang = new Barang
            {
                nama_barang = namaBx.Text,
                harga_awal = hargaAwal,
                tgl = tglDate.Value.Date,
                deskripsi_barang = descBx.Text
            };

            db.Barangs.Add(newBarang);
            db.SaveChanges();
            MessageBox.Show("Udhi berhasil ditambah");
            LoadData();
            ClearFields();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            ButtonEditAndDelete(false);
            ClearFields();
            barang = null;
        }

        private void dgvBarang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var id = (int) dgvBarang.Rows[e.RowIndex].Cells["id_barang"].Value;
                ButtonEditAndDelete(true);
                saveBtn.Enabled = false;
                barang = db.Barangs.Find(id);
                namaBx.Text = barang.nama_barang;
                hargaAwalBx.Text = barang.harga_awal.ToString();
                descBx.Text = barang.deskripsi_barang;
                tglDate.Value = barang.tgl;
            }
            catch
            {

            }
        }

        private void editBtn_Click(object sender, EventArgs e)
        {
            if (!(int.TryParse(hargaAwalBx.Text, out int hargaAwal)))
            {
                MessageBox.Show("Harga harus berisi digit");
                return;
            }
            barang.nama_barang = namaBx.Text;
            barang.harga_awal = hargaAwal;
            barang.tgl = tglDate.Value;
            barang.deskripsi_barang = descBx.Text;

            db.SaveChanges();
            MessageBox.Show("Kur Berhasil di edit/update");
            LoadData();
            ClearFields();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            db.Barangs.Remove(barang);
            db.SaveChanges();
            MessageBox.Show("Kur Berhasil di haa");
            LoadData();
            ClearFields();
        }
    }
}
