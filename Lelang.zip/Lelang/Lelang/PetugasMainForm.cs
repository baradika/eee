﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lelang
{
    public partial class PetugasMainForm : Form
    {
        public PetugasMainForm()
        {
            InitializeComponent();
        }

        private void PetugasMainForm_Load(object sender, EventArgs e)
        {
            var user = Util.userPetugas;
            namaLbl.Text = user.nama_petugas;
            levelLbl.Text = user.Level.level1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new BarangForm().ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new LelangForm().ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new LaporanForm().ShowDialog();
        }
    }
}
