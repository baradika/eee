﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lelang
{
    public partial class Form1 : Form
    {
        LelangEntities db = new LelangEntities();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var masyarakat = db.Masyarakats.FirstOrDefault(user => user.username == userBx.Text && user.password == passBx.Text);
            var petugas = db.Petugas.FirstOrDefault(user => user.username == userBx.Text && user.password == passBx.Text );

            if( masyarakat != null && petugas == null)
            {
                Util.userMasyarakat = masyarakat;
                new MasyarakatMainForm().Show();
                this.Hide();
            }else if( petugas != null && masyarakat == null )
            {
                Util.userPetugas = petugas;
                new PetugasMainForm().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Role tidak valid, silahkan hubungi admin");
            }
        }


    }
}
