﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lelang
{
    public partial class LaporanForm : Form
    {
        LelangEntities db = new LelangEntities();
        int keuntungan = 0;
        public LaporanForm()
        {
            InitializeComponent();
        }

        private void LaporanForm_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            dgvLaporan.DataSource = db.Lelangs
                .Where(lelang=> lelang.status.ToLower() == "ditutup" && lelang.harga_akhir != null)
                .AsEnumerable()
                .Select(lelang => new {
                    lelang.Barang.nama_barang,
                    lelang.Barang.harga_awal,
                    lelang.Masyarakat.namaLengkap,
                    lelang.harga_akhir,
                    Keuntungan = lelang.harga_akhir - lelang.Barang.harga_awal
                }).ToList();
        }

        private void LoadDataFilter()
        {
            var start = dateStartPicker.Value;
            var end = dateEndPicker.Value;
            var idBarang = barangBx.SelectedValue as int?;

            var query = db.Lelangs
                .Where(l => l.status.ToLower() == "ditutup" && l.harga_akhir != null
                            && l.tgl_lelang >= start && l.tgl_lelang <= end);

            if (idBarang.HasValue)
                query = query.Where(l => l.id_barang == idBarang.Value);

            dgvLaporan.DataSource = query
                .AsEnumerable()
                .Select(l => new
                {
                    l.Barang.nama_barang,
                    HargaAwal = Util.toRupiah(l.Barang.harga_awal),
                    l.Masyarakat.namaLengkap,
                    HargaAkhir = Util.toRupiah(l.harga_akhir.Value),
                    Keuntungan =Util.toRupiah( l.harga_akhir.Value - l.Barang.harga_awal)
                })
                .ToList();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            LoadDataFilter();
        }
    }
}
