﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lelang
{
    public partial class MasyarakatMainForm : Form
    {
        LelangEntities db = new LelangEntities();
        Lelang lelang = null;
        public MasyarakatMainForm()
        {   
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void MasyarakatMainForm_Load(object sender, EventArgs e)
        {
            var user = Util.userMasyarakat;
            namaLbl.Text = user.namaLengkap;
            LoadData();
        }

        private void LoadData()
        {
            dgvLelang.DataSource = db.Lelangs.Where(lelang=> lelang.status.ToLower() == "dibuka").AsEnumerable().Select(lelang => new
            {
                lelang.id_lelang,
                lelang.Barang.nama_barang,
                lelang.Barang.harga_awal,
                lelang.Barang.deskripsi_barang,
                pelelang = lelang.Masyarakat?.namaLengkap ?? "Belum ada yang menawar",
                harga_akhir = Util.toRupiah(lelang.harga_akhir ?? 0)
            }).ToList();
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Close();
        }

        private void dgvLelang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var id = (int) dgvLelang.CurrentRow.Cells["id_lelang"].Value;
                lelang = db.Lelangs.Find(id);
                if (lelang.harga_akhir != null)
                {
                    tawarBx.Minimum = (decimal) lelang.harga_akhir + 1;
                    tawarBx.Value = (decimal)lelang.harga_akhir;
                }
            }
            catch
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lelang.harga_akhir = (int) tawarBx.Value;
            lelang.id_user = Util.userMasyarakat.id_user;
            lelang.tgl_lelang = DateTime.Now.Date;

            var newHistory = new HistoryLelang
            {
                id_lelang = lelang.id_lelang,
                id_barang = lelang.id_barang,
                id_user = Util.userMasyarakat.id_user,
                penawaran_harga = (int) tawarBx.Value
            };

            db.HistoryLelangs.Add(newHistory);
            db.SaveChanges();
            MessageBox.Show("Berhasil ditawar");
            LoadData();
        }
    }
}
