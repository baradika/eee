﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Lelang
{
    public partial class LelangForm : Form
    {
        LelangEntities db = new LelangEntities();
        Lelang lelang = null;
        public LelangForm()
        {
            InitializeComponent();
        }

        private void LelangForm_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadDataBarang();
        }

        public void ButtonEditAndDelete(Boolean status)
        {
            editBtn.Enabled = status;
            deleteBtn.Enabled = status;
        }

        private void LoadData()
        {
            db = new LelangEntities();
            dgvLelang.DataSource = db.Lelangs.AsEnumerable().Select(x => new
            {
                x.id_lelang,
                x.Barang.nama_barang,
                x.Barang.harga_awal,
                x.Barang.deskripsi_barang,
                pelelang = x.Masyarakat?.namaLengkap ?? "Belum ada yang menawar",
                harga_akhir = Util.toRupiah(x.harga_akhir ?? 0),
                x.status
            }).ToList();
        }

        private void LoadDataBarang()
        {
            barangBx.DataSource = db.Barangs.ToList();
            barangBx.ValueMember = "id_barang";
            barangBx.DisplayMember = "nama_barang";
        }

        private void Save()
        {
            if(!(barangBx.SelectedValue is int idBarang))
            {
                MessageBox.Show("barang tidak valid");
                return;
            }

            var newLelang = new Lelang
            {
                id_barang = idBarang,
                status = statusBx.Text,
                tgl_lelang = DateTime.Now.Date,
                id_petugas = Util.userPetugas.id_petugas
            };

            db.Lelangs.Add(newLelang);
            db.SaveChanges();
            MessageBox.Show("Berhasil tambah lelang");
            LoadData();
            ClearFields();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void dgvLelang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var id = (int)dgvLelang.Rows[e.RowIndex].Cells["id_lelang"].Value;
                ButtonEditAndDelete(true);
                button1.Enabled = false;
                lelang = db.Lelangs.Find(id);
                barangBx.SelectedValue = lelang.id_barang;
                statusBx.Text = lelang.status;
            }
            catch
            {

            }
        }

        private void ClearFields()
        {
            barangBx.SelectedIndex = 0;
            statusBx.SelectedIndex = 0;
            lelang = null;
            ButtonEditAndDelete(false);
            button1.Enabled = true;
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void editBtn_Click(object sender, EventArgs e)
        {
            Edit();
        }

        private void Edit()
        {
            if (!(barangBx.SelectedValue is int idBarang))
            {
                MessageBox.Show("barang tidak valid");
                return;
            }
            if(statusBx.Text == string.Empty)
            {
                MessageBox.Show("status belum diisi");
                return;
            }
            lelang.id_barang = idBarang;
            lelang.status = statusBx.Text;

            db.SaveChanges();
            MessageBox.Show("Lelang berhasil diedit");
            LoadData();
            ClearFields();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            db.Lelangs.Remove(lelang);
            db.SaveChanges();
            MessageBox.Show("Lelang berhasil dihapus");
            LoadData();
            ClearFields();
        }
    }
}
